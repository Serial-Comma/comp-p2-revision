import datetime, pymongo

client = pymongo.MongoClient("127.0.0.1", 27017)
db = client.get_database("mims")
coll = db.get_collection("password")

def task3_1(strdate, n):
    date = datetime.datetime.strptime(strdate, "%Y%m%d")
    #print(date)

    new_date = date + datetime.timedelta(days = n)
    date_string = new_date.strftime("%Y%m%d")

    return date_string

def task3_4(strdate):

    expiry_date = task3_1(strdate, 10)
    
    query = {"Date_next_reset": {"$lt": expiry_date}} # Check if expiry_date need convirt to int
    result = coll.find(query)
    for row in result:
        print(row)
        name = row["Name"]
        date_next_reset = row["Date_next_reset"]
    
        email = f"Dear {name},\n\nYour MIMS account password will be expiring soon.\
 Please perform a self-reset of your MIMS account password by {date_next_reset}"

        with open("EMAIL_REMINDER.txt", "a") as f:
            f.write(email + "\n\n")

task3_4("20230704")
