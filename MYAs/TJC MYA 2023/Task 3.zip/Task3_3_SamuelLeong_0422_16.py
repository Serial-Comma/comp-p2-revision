import pymongo, datetime

client = pymongo.MongoClient("127.0.0.1", 27017)
db = client.get_database("mims")
coll = db.get_collection("password")

def task3_1(strdate, n):
    date = datetime.datetime.strptime(strdate, "%Y%m%d")
    #print(date)

    new_date = date + datetime.timedelta(days = n)
    date_string = new_date.strftime("%Y%m%d")

    return date_string

def task3_3(_id, strdate):
    new_date = task3_1(strdate, 90) # get new exp date

    result = coll.find({"ID": "1"}) # find and update id=1
    for row in result:
        print(row)

    query = {"ID": {"$eq": _id}}
    update = {"$set": {"Date_last_reset": strdate}}
    coll.update_one(query, update) # update values
    update = {"$set": {"Date_next_reset": new_date}}
    coll.update_one(query, update) # update values

# Testing
task3_3("1", "20230704")
result = coll.find({"ID": {"$eq": "1"}})
for row in result:
    print(row)
