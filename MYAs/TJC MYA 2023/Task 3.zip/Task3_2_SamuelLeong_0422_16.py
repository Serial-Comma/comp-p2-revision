import pymongo, csv, datetime

def task3_1(strdate, n):
    date = datetime.datetime.strptime(strdate, "%Y%m%d")
    #print(date)

    new_date = date + datetime.timedelta(days = n)
    date_string = new_date.strftime("%Y%m%d")

    return date_string

#print(task3_1("20230704", 90))


client = pymongo.MongoClient("127.0.0.1", 27017)
db = client.get_database("mims")

#db.drop_collection("password") # Reset coll for testing, can ignore
coll = db.get_collection("password")


with open("MIMS.txt", "r") as f:
    reader = csv.reader(f)
    for row in reader:
        nxt_reset = task3_1(row[4], 90)
        dic = {}
        dic["ID"] = row[0]
        dic["Name"] = row[1]
        dic["Account"] = row[2]
        dic["Date_onboarded"] = row[3]
        dic["Date_last_reset"] = row[4]
        dic["Date_next_reset"] = nxt_reset
        coll.insert_one(dic) # Insert dictionary into pymongo

# Testing
result = coll.find()
for row in result:
    print(row)

