import datetime

def task3_1(strdate, n):
    date = datetime.datetime.strptime(strdate, "%Y%m%d") # strptime method
    #print(date)

    new_date = date + datetime.timedelta(days = n) # timedelta method
    date_string = new_date.strftime("%Y%m%d") # strftime method

    return date_string

print(task3_1("20230704", 90))
